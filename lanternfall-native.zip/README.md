# Lanternfall: native build

Plain HTML/JS game wrapped with Capacitor. The web files are in this folder root.

## Android APK without a computer toolchain (GitHub Actions)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's Actions tab. "Build Android APK" runs on every push (or press Run workflow).
3. When it finishes (about 5 minutes), open the run and download the `lanternfall-debug-apk` artifact. Unzip it to get `app-debug.apk`.
4. Copy the APK to your Android phone, open it, and allow "install unknown apps" when asked.

This is a debug build for personal use. For Google Play you need a signed release bundle (see below).

## Android on your own machine
Needs Node 18+, JDK 17, Android Studio.
```
mkdir www && cp index.html manifest.webmanifest sw.js www/ && cp -r icons www/
npm install
npx cap add android
npx cap sync android
npx cap open android     # Run from Android Studio, or Build > Build Bundle(s)/APK(s)
```

## iOS (Mac with Xcode only)
```
mkdir -p www && cp index.html manifest.webmanifest sw.js www/ && cp -r icons www/
npm install
npx cap add ios
npx cap sync ios
npx cap open ios
```
Choose your Apple developer team under Signing & Capabilities, then Run. A free Apple ID installs to your own device for 7 days; the App Store needs a paid developer account.

## Before publishing
- Change `appId` in `capacitor.config.json` (for example `com.yourname.lanternfall`). It can't change after release.
- Play Store: in Android Studio use Build > Generate Signed Bundle, create a keystore, and keep it safe.
- Fonts load from Google Fonts and fall back to system fonts offline. Bundle them into `www/fonts` if you want identical offline visuals.
